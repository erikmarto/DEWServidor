<?php
$db = new mysqli('localhost', 'test', 'test', 'test_libros');

if ($db->connect_errno)
    die( "Error: Fallo al conectarse a MySQL :". $mysqli->connect_error );


// Realizar una consulta SQL
$sql = "SELECT * from categorias order by id";
if (!$resultado = $db->query($sql)) {
    die( "Error: " . $db->error );
}

if ($resultado->num_rows === 0) {
    die( "No hay datos...");
}

// Imprimir los resultados en HTML
echo "<table><tr><td>Id<td>Categoría</tr>\n";
while ($datos = $resultado->fetch_assoc()) {
    //var_dump($art);
    echo "<tr>";
    echo "<td>".$datos['id'].'<td>'.$datos['nombre'];
    echo "</tr>";
}
echo "</table>\n";

$db->close();
