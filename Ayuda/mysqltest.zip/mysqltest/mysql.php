<?php
// Acceso a base de datos MySQL con la libreria mysql

$db = mysql_connect('localhost', 'test', 'test')
    or die('No se pudo conectar: ' . mysql_error());

mysql_select_db('test_libros') or die('No se pudo seleccionar la base de datos');


// Realizar una consulta MySQL
$query = 'SELECT * FROM categorias order by id';
$result = mysql_query($query) or die('Consulta fallida: ' . mysql_error());

// Imprimir los resultados en HTML
echo "<table><tr><td>Id<td>Categoría</tr>\n";
while ($datos = mysql_fetch_array($result, MYSQL_ASSOC)) {
    //var_dump($art);
    echo "<tr>";
    echo "<td>".$datos['id'].'<td>'.$datos['nombre'];
    echo "</tr>";
}
echo "</table>\n";

// Cerrar la conexión
mysql_close($db);
?>

