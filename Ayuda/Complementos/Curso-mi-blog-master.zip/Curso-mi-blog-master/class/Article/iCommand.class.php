<?php 

interface iCommand
{
  public function exec();
}
