<?php 
/**
* 
*/
abstract class Message
{
  abstract public function getMessage (string $message): string;
}
