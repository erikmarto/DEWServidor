<div class="col-sm-3 col-md-2 sidebar">
  <ul class="nav nav-sidebar">
    <li><a href="dashboard.php">Overview</a></li>
    <li><a href="post.php">New post</a></li>
  </ul>
</div>