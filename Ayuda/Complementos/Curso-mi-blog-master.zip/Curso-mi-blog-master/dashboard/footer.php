
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="../js/jquery-3.1.1.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script  type="text/javascript" src="../js/categorie/categorie.js"></script>
    <script  type="text/javascript" src="../js/article/article.js"></script>
  </body>
</html>