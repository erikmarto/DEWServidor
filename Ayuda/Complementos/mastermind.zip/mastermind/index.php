<?php
require 'mastermind.class.php';

session_start();
if (isset($_GET['reset'])) {
    session_destroy();
    session_start();
}

if (isset($_POST['level'])) {
    $mm = new mastermind($_POST['level']);
    $_SESSION['mastermind'] = $mm;
   header("location: game.php");
}

include 'view/picklevel.php';

?>