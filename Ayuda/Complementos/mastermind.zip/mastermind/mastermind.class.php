<?php

class mastermind{
    private $currentLevel;
    private $isOver = false;
    private $rounds = [];
    private $winningNumber;
    const LEVELS = [
        0 => [
            'name' => 'Baby\'s First Mastermind',
            'max' => 3,
            'length' => 2,
            'gameLength' => 4
        ],
        1 => [
            'name' => 'Easy',
            'max' => 4,
            'length' => 3,
            'gameLength' => 7
        ], 
        2 => [
            'name' => 'Standard',
            'max' => 6,
            'length' => 4,
            'gameLength' => 10
        ], 
        3 => [
            'name' => 'Hard',
            'max' => 9,
            'length' => 4,
            'gameLength' => 13
        ],
        4 => [
            'name' => 'Expert',
            'max' => 6,
            'length' => 5,
            'gameLength' => 16
        ],
        5 => [
            'name' => 'Dante Must Die',
            'max' => 9,
            'length' => 5,
            'gameLength' => 19
        ]
    ];

    /** Generates a random number with no repeating digits when a mastermind object gets instanced.
     * 
     */
    public function __construct($lvl) {
        $this->currentLevel = $lvl ?? 2; //defaults to hard
        $max = mastermind::LEVELS[$lvl]['max'] ?? 6; //defaults to hard
        $length = mastermind::LEVELS[$lvl]['length'] ?? 4; //defaults to hard

        //generate winning number
        $this->winningNumber = range(1, $max);
        shuffle($this->winningNumber);
        $this->winningNumber = array_slice($this->winningNumber, 0, $length);
    }

    /** Checks if number has already been played by the user.
     * 
     */
    private function numberAlreadyPlayed($n) {
        $alreadyPlayed = false;
        if (isset($this->rounds[0])) {
            for ($i = 0; $i < count($this->rounds) && !$alreadyPlayed ;$i++) {
                if ($this->rounds[$i]['userNumber'] == $n) {
                    $alreadyPlayed = true;
                }
            }
        }
        return $alreadyPlayed;
    }

    /** Checks if array has duplicates
     * 
     */
    private function hasRepeatedNumbers($array) {
        return count($array) !== count(array_flip($array));
    }

    /** Checks if any digit goes over max difficulty number
     * 
     */
    private function digitOutsideBounds($array) {
        $isOverMaxValue = false;
        for($i = 0;$i < count($array) && !$isOverMaxValue ;$i++) {
            if ($array[$i] > mastermind::LEVELS[$this->currentLevel]['max'] || $array[$i] < 1) {
                $isOverMaxValue = true;
            }
        }
        return $isOverMaxValue;
    }

    /** Validates input number against the winning number and returns a numeric value representing the status of the game.
     * 
     *  0 -> valid number, user hasn't finished the game
     *  1 -> User won the game
     *  2 -> User ran out of tries
     *  3 -> Invalid length
     *  4 -> Repeated digits in user input
     *  5 -> User number's digit outside digit bounds 
     *  6 -> Number has already been played by user
     * 
     */
    public function validate($userAttempt) {
        $numberArray = array_map('intval', str_split($userAttempt));
        //TODO check if 
        //validate if number's length is correct
        if (count($numberArray) !== mastermind::LEVELS[$this->currentLevel]['length']) {
            $gameCode = 3;
        } else if ($this->hasRepeatedNumbers($numberArray)) {
            $gameCode = 4;
        } else if ($this->digitOutsideBounds($numberArray)) {
            $gameCode = 5;
        } else if ($this->numberAlreadyPlayed($userAttempt)) {
            $gameCode = 6;
        } else {
            $gameCode = $this->checkInput($numberArray);
        }

        return $gameCode;
    }

    /** Checks $userNumber against the winning number and saves the round's stats
     * 
     */
    private function checkInput($userNumber) {
        $gameCode = 0;
        $res = [
            'black' => 0,
            'white' => 0
        ];

        foreach($userNumber as $pos => $n) {
            if ($n == $this->winningNumber[$pos]) {
                $res['black']++;
            } else if (in_array($n, $this->winningNumber)) {
                $res['white']++;
            }
        }

        if ($res['black'] == mastermind::LEVELS[$this->currentLevel]['length']) {
            $this->isOver = true;
            $gameCode = 1;
        }

        $round = [
            'userNumber' => implode('', $userNumber),
            'clues' => $res
        ];

        $this->rounds[] = $round;

        if ($this->getRemainingTries() == 0 && $gameCode == 0) {
            $gameCode = 2;
        }
        return $gameCode;
    }
    /** Returns the winning number
     * 
     */
    public function getWinningNumber() {
        return implode('', $this->winningNumber);
    }

    /** Returns a boolean value representing whether the number has been guessed or not.
     * 
     */
    public function isGameOver() {
        return $this->isOver;
    }

    public function getRounds() {
        return $this->rounds;
    }

    public function getCurrentLevel() {
        return $this->currentLevel;
    }

    public function getRemainingTries() {
        return mastermind::LEVELS[$this->currentLevel]['gameLength'] - count($this->rounds);
    }
}
?>