<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Page Title</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="style/style.css" />
</head>
<body>
    <div class="container">
        <h1 class="game-prompt">MASTERMIND</h1>
        <h3 class="game-prompt">Elija el nivel de dificultad:</h3>
        <form method="post">
            <div class="form-items">
                <select name="level">
                <?php
                    foreach(mastermind::LEVELS as $level => $levelInfo) {
                        echo "<option value=$level>$levelInfo[name]</option>";
                    }
                ?>
                </select>
                <button>Empezar</button> 
            </div>
        </form>
        <div>
            <p class="game-prompt">El objetivo de este juego es, mediante la entrada de diferentes números, 
            inferir el número secreto generado por el programa al comenzar la partida.</p>
            <p class="game-prompt">El programa analizará el número introducido, y mostrará unas pistas basadas
            en la similitud de su número y el número secreto.</p>
            <p class="game-prompt">Hay dos tipos de pista: </p> 
            <li class="game-prompt">Pista blanca: Uno de los dígitos del número introducido se encuentra en el número secreto, pero no está en la posición correcta.</li>
            <li class="game-prompt">Pista negra: Uno de los dígitos del número introducido se encuentra en el número secreto y está está en la posición correcta.</li>
            <p class="game-prompt">El número de intentos está limitado y varía según el nivel seleccionado. 
            Encontrar una lista de la configuración de los diferentes niveles más adelante.</p>
        </div>
    </div>
</body>
</html>