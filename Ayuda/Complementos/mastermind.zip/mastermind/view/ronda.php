<?php
if ($times > 0) {
    echo '<div class="rounds"><p class="grid-header">Turno</p><p class="grid-header">Número</p><p class="grid-header">Pistas</p>';
    foreach($rounds as $roundNumber => $round) {
?>
<!--<div class='round'>-->
    <div><p><?=$roundNumber+1?></p></div>
    <div><p><?=$round['userNumber']?></p></div>
    <div class='clues'>
        <?php
        for ($i = 0; $i < $round['clues']['black'] ;$i++) {
            echo "<div class='clue black'></div>";
        }
        for ($i = 0; $i < $round['clues']['white']; $i++) {
            echo "<div class='clue white'></div>";
        }
        ?>
    </div>
<!--</div>-->
<?php
    }
    echo '</div>';
}
else {
    echo '<p class="game-prompt">Primer turno, sin historial.</p>';
}
?>