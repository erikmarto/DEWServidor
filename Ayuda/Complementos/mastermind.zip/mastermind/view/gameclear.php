<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Eres la Mente Maestra</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="style/style.css" />
</head>
<body>
    <div class="container">
        <h1 class="game-prompt">WINRAR</h1>
        <p class="game-prompt">Has tardado <?=$times?> ronda<?=$times>1?'s':''?></p>
        <p class="game-prompt">El número ganador es <?=$winningNumber?><p>



        <?php
            include 'view/ronda.php';
        ?>
        <a class="game-prompt" href="index.php?reset">Jugar de nuevo</a>
    <div>
</body>
</html>