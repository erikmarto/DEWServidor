<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>DEP</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="style/style.css" />
</head>
<body>
    <div class="container">
        <h1 class="game-prompt">HAS PERDIDO</h1>
        <p class="game-prompt">No has conseguido adivinar el número secreto: <?=$winningNumber?>.</p>

        <?php
            include 'view/ronda.php';
        ?>
        <a class="game-prompt" href="index.php?reset">Inténtalo de nuevo.</a>
    <div>
</body>
</html>