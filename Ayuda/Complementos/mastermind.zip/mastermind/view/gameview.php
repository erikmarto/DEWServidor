<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Mastermind</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="style/style.css" />
</head>
<body>
    <div class="container">
        <h1 class="game-prompt">MASTERMIND</h1>
        <p class="game-prompt"><?=$errorMessage?></p>
        <h3 class="game-prompt">Introduzca un número:</h3>
        <form method="post">
            <div class="form-items">
                <input type="number" name="userInput" placeholder="Longitud: <?=$inputLength?> cifras">
                <button>Comprobar</button>
            </div>
        </form>
        <h4 class="game-prompt">Rondas restantes: <?=$remainingTries?></h3>
        <?php
        include 'ronda.php';
        ?>
        <p class="game-prompt">Número ganador: <?=$winningNumber?></p>
        <a href="index.php?reset" class="game-prompt">Volver a empezar</a>
    </div>
</body>
</html>