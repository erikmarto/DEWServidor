<?php

require 'mastermind.class.php';
session_start();


$mm = $_SESSION['mastermind'];


$gameCode = isset($_POST['userInput'])?$mm->validate($_POST['userInput']):0;


$winningNumber = $mm->getWinningNumber();
$inputLength = mastermind::LEVELS[$mm->getCurrentLevel()]['length'];
$maxDigitValue = mastermind::LEVELS[$mm->getCurrentLevel()]['max'];
$rounds = $mm->getRounds();
$remainingTries = $mm->getRemainingTries();
$times = count($rounds) ?? 0;

/**
 *  0 -> valid number, user hasn't finished the game
 *  1 -> User won the game
 *  2 -> User ran out of tries
 *  3 -> Invalid length
 *  4 -> Repeated digits in user input
 *  5 -> User number's digit over maximum digit value
 *  6 -> Number has already been played by user
 * 
 */
$errorMessages = [
    0 => '', 
    3 => "La longitud del número introducido debe ser de $inputLength cifras.", 
    4 => 'El número no puede tener dígitos repetidos.',
    5 => "Todos los dígitos deben estar entre 1 y $maxDigitValue",
    6 => 'El número introducido ya ha sido jugado en otra ronda.'
];

switch ($gameCode) {
    case 0:
    case 3:
    case 4:
    case 5:
    case 6:
        $errorMessage = $errorMessages[$gameCode];
        include 'view/gameview.php';
    break;
    case 1:
        include 'view/gameclear.php';
    break;
    case 2:
        include 'view/gameover.php';
    break;
}
?>