<div class="col-12 col-md-1 col-xl-2 sidebar bg-light content">
</div>
<div id="main-content" class="col-12 col-md-10 col-xl-8 content">
    <h1 class="display-4">Bandeja de entrada</h1>
    <p class="lead">De <?=$usuario->usuario?></p>
    <hr class="header-separator">

    <p class="lead">Aquí se mostrará la bandeja de entrada del usuario</p>
</div>
<div class="col-12 col-md-1 col-xl-2 sidebar bg-light content">
</div>