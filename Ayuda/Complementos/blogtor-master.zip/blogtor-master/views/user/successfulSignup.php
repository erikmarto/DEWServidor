<div class="col-12 col-md-1 col-xl-2 sidebar bg-light content">
</div>
<div id="main-content" class="col-12 col-md-10 col-xl-8 content">
    <h3 class="text-center">Usuario registrado con éxito!</h3>
    <p class="text-center lead">Espere a que un administrador apruebe su usuario.</p>
</div>
<div class="col-12 col-md-1 col-xl-2 sidebar bg-light content">
</div>