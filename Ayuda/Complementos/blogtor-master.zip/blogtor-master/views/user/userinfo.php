<div class="col-12 col-md-1 col-xl-2 sidebar bg-light content">
</div>
<div id="main-content" class="col-12 col-md-10 col-xl-8 content">
    <h3>Información del usuario:</h3>
    <p>Nombre de usuario: <?=$usuario->usuario?></p>
    <p>Nombre: <?=$usuario->nombre?></p>
    <p>Email: <?=$usuario->email?></p>
    <p>Estado: <?=$usuario->estado?></p>
</div>
<div class="col-12 col-md-1 col-xl-2 sidebar bg-light content">
</div>