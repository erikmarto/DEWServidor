
<div class="col-12 col-md-1 col-xl-2 sidebar bg-light content">
</div>
<div id="main-content" class="col-12 col-md-10 col-xl-8 content">
    <p><?=$mensaje?></p>
</div>
<div class="col-12 col-md-1 col-xl-2 sidebar bg-light content">
</div>