<h6>
    <div class='avatar-small d-inline-block'>
        <div id='avatarImg<?=$entrada->usuarios_id?>' style='background-image: url(<?=$entrada->profile_pic_path?>)'></div>
    </div>
    <a href='?r=blog/userblog&id=<?=$entrada->usuarios_id?>'><small class='color-secondary'><?=$entrada->nombre?></small></a>
</h6>