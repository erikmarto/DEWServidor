<h1 class="text-center blog-title">Blog de <a href="?r=user/userinfo&id=<?=$usuario->id?>"><?=$usuario->nombre?></a></h1>
<div class="avatar-upload">
    <div class="avatar-preview">
        <div id="imagePreview" style="background-image: url(<?=$usuario->profile_pic_path?>);">
        </div>
    </div>
</div>