<h1 class="text-center blog-title">Resultados de la búsqueda:</h1>
