<div class="col-12 col-md-1 col-xl-2 sidebar bg-light content">
</div>
<div id="main-content" class="col-12 col-md-10 col-xl-8 content">
<h1 class="display-4">Panel de administrador</h1>
    <p class="lead">índice</p>
    <hr class="header-separator">

    <h3 class="display-6"><a href="?r=admin/ApproveUsuarios">Aceptar Usuarios</a></h3>

    <h3 class="display-6"><a href="?r=admin/ApproveEntradas">Aceptar Entradas</a></h3>

    <h3 class="display-6"><a href="?r=admin/ApproveComentarios">Aceptar Comentarios</a></h3>

</div>
<div class="col-12 col-md-1 col-xl-2 sidebar bg-light content">
</div>