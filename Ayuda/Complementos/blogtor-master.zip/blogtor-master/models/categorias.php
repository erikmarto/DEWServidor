<?php

class categorias extends model {
    static $tablename="categorias";
    static $attributes;

}
?>