<?php

class entradas_cat_usuario extends model {
    static $tablename="entradas_cat_usuario";
    static $attributes;


    
}
?>