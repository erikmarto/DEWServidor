<?php

class comentarios_cat_usuarios extends model {
    static $tablename="comentarios_cat_usuarios";
    static $attributes;
}
?>