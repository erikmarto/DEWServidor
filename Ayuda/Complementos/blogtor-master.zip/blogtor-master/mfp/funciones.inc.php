<?php

// Funciones generales. Utilizables en cualquier aplicaci�n




?>
